Planning:
What type of website is this?
- Selling weapons? 
- Fantasy theme!!!
- What type of currency are we using? 

Categories:
1) weapons
- sticks
- bowl
- fishing rod
2) armor/ clothing
SUPERIDOL SUNGLASSES
3) Accessories
- 1000 year old gum
- Potion of Strength
- Potion of Speed
4) Misc Items

Webpages need
- Homepage(navigation, categories)
- Weapons page (for each individual item?)
- Armor page
- Powerup page
- Cart (in future)
- Payment page
- Thank you for purchasing this item press here to return to main page

1st page content:
- pictures with links to navbar links?
- About: can go this id, 
- In need of tools to survive the apocalypse? Fret not for we have u covered!


THings to fix:

width 768px-991px

edit the product page so that maybe 4 categories?

Contact us page